var attempts = 0
var togglecheck = 0
var answered = 4
var counter = 0

function results() {
  let score = 0;
  if(attempts >= 1){
    let lastWrong = document.getElementsByClassName(`wrong`);
    let lastCorrect = document.getElementsByClassName(`correct`);
    let lastCorrectRepeat = lastCorrect.length + 1
    let lastWrongRepeat = lastWrong.length + 1
    for (let j = 1; j < lastWrongRepeat; j++){
      lastWrong[0].classList.toggle(`prevWrong`);
      lastWrong[0].classList.toggle(`wrong`);
    }
    for(let k = 1; k < lastCorrectRepeat; k++){
      lastCorrect[0].classList.toggle(`prevCorrect`);
      lastCorrect[0].classList.toggle(`correct`);
    }
  }
  /* attempts += 1;
  document.getElementById(`Attempt`).innerHTML = `Attempts: ${attempts}`; */
  for (let i = 1; i < 5; i++) {
      let a = document.querySelector(`input[name="Q${i}"]:checked`);
      /* document.getElementsByTagName("div")[i+1].style.background = "color-mix()"; */
      document.getElementsByTagName("fieldset")[i-1].style.opacity = "1";
      if (a != null) {
          if (a.value == 1) {
            score += 1;
            /* a.parentElement.style.backgroundColor = "green";
            a.parentElement.style.opacity = "1"; */
            if(a.parentElement.classList[0] == "prevCorrect"){
              a.parentElement.classList.toggle(`prevCorrect`)
            }
            a.parentElement.classList.toggle(`correct`)
          } 
          else {
            /* a.parentElement.style.backgroundColor = "red";
            a.parentElement.style.opacity = "1"; */
            if(a.parentElement.classList[0] == "prevWrong"){
              a.parentElement.classList.toggle(`prevWrong`)
            }
            a.parentElement.classList.toggle(`wrong`)
          }
        } 
        else {
          /* playStalker(); */
          alert(`Q${i} cannot be marked due to no valid input being recognized, please make sure you have answered the question.`);
          answered -= 1;
          document.getElementsByTagName("fieldset")[i-1].style.opacity = "0.5";
        }
  }
    alert("Attempted Submitted!");
    if (score == 4) {
      document.getElementById(`Result`).innerHTML = "Your score is 4/4! Great Job!";
      playVideo();
      alert("Perfect!");
      attempts += 1;
      document.getElementById(`Attempt`).innerHTML = `Attempts: ${attempts}`;
    } 
    else {
      playVid();
      document.getElementById(`Result`).innerHTML = `Your score is ${score}/4. Look back through and review your answers`;
      attempts += 1;
      document.getElementById(`Attempt`).innerHTML = `Attempts: ${attempts}`;
    }
   answered = 4
}
function darkmode(){
  document.body.classList.toggle('dark')
  document.getElementById(`header`).classList.toggle('dark')
  if(togglecheck == 0) {
    togglecheck = 1;
    document.getElementById(`bgchange`).innerHTML = "Change to Light Mode";
    return;
  }
  if(togglecheck == 1) {
    togglecheck = 0;
    document.getElementById(`bgchange`).innerHTML = "Change to Dark Mode"
    return;
  }
}
function playVid() {
  let audioPlay = document.getElementById("myAudio"); 
  audioPlay.play(); 
} 
function playVideo() {
  let audioPlay1 = document.getElementById("myAudio1"); 
  audioPlay1.play(); 
} 

function playStalker(){
  let audioPlay2 = document.getElementById("myAudio2");
  audioPlay2.play();
}